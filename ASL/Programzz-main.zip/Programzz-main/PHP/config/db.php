<?php

    $con = mysqli_connect("localhost", "root", "", "seniorcitizens");
    if(!$con){
        die("Connection Failed");
    }
?>